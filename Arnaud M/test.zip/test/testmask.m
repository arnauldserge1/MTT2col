function masque=testmask(dic,rayon,a)

dic=imdetail(dic,rayon);

u = 15;
ui = 5;
pasencorebon = 1;
imsize = size(dic);
a=0;
nbpas = 0;

im = imadjust(dic);
h = figure;
set(h,'Position',[384 70 imsize]);
iptsetpref('ImshowBorder','tight')


    while pasencorebon
        pasencorebon = 0;

        % traitement d'image (intensif voire mauvais traitement car tr�s
        % intensif... pauvre image.

        [junk threshold] = edge(im, 'sobel'); %#ok
        BWs = edge(im,'sobel', threshold * sqrt(threshold)+a);

        se0 = strel('disk', u);
        BWsdil = imdilate(BWs, se0);
        BWdfill = imfill(BWsdil,4,'holes');

        seD = strel('diamond',ui);
        BWfinal1 = imerode(BWdfill,seD);
        BWfinal2 = imerode(BWfinal1,seD);
        BWfinal = ~imfill(~BWfinal2,'holes');
        BWoutline = bwperim(BWfinal);
        espace = bwarea(BWfinal)*100/(imsize(1)*imsize(2));

        if espace>90 % petit teste un peu grossier mais qui marche
            disp('loup�...')
            pasencorebon = 1;
            a = a + 0.03;
        elseif  espace<40 % idem
            disp('loup�...')
            pasencorebon = 1;
            a = a - 0.02;
        end

        if ~pasencorebon % on demande si ca convient
            Segout = im;
            se1 = strel('disk', 2, 0);
            Segout(imdilate(BWoutline, se1)) = 900;
            imshow(Segout);
            button3 = questdlg('Ca te convient ?','Alors ...','Yes');
            if strcmpi(button3,'No')
                button4 = questdlg('Dis-moi si le contour est trop grand ou trop petit','rectifion','trop grand','trop petit','trop grand');
                pasencorebon = 1;
                nbpas = nbpas + 1;
                if strcmpi(button4,'trop grand')
                    a = a + 0.07/nbpas;
                elseif strcmpi(button4,'trop petit')
                    a = a - 0.08/nbpas;
                else
                    disp('ciao...')
                    BWaire = [];
                    return
                end
            end
        end

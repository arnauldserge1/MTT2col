function varargout = testdegraph(varargin)
% TESTDEGRAPH M-file for testdegraph.fig
%      TESTDEGRAPH, by itself, creates a new TESTDEGRAPH or raises the existing
%      singleton*.
%
%      H = TESTDEGRAPH returns the handle to a new TESTDEGRAPH or the handle to
%      the existing singleton*.
%
%      TESTDEGRAPH('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TESTDEGRAPH.M with the given input arguments.
%
%      TESTDEGRAPH('Property','Value',...) creates a new TESTDEGRAPH or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before testdegraph_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to testdegraph_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help testdegraph

% Last Modified by GUIDE v2.5 17-Jul-2007 11:52:12

% Begin initialization code - DO NOT EDIT



gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @testdegraph_OpeningFcn, ...
                   'gui_OutputFcn',  @testdegraph_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

files=sbe('\\Pcmicrovideo\dataD\HIV\2007-06-19 test spinoc\DIC\JRFLwt1.tif');
dicinit=imread([files.directory, files.name]);

% --- Executes just before testdegraph is made visible.
function testdegraph_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to testdegraph (see VARARGIN)

files=sbe('\\Pcmicrovideo\dataD\HIV\2007-06-19 test spinoc\DIC\JRFLwt1.tif');
dicinit=imread([files.directory, files.name]);

handles.current_data=imshow(imadjust(dicinit));


% Choose default command line output for testdegraph
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes testdegraph wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = testdegraph_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in okpushbutton.
function okpushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to okpushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

a=1;
close(testdegraph);
disp(num2str(a));


% --- Executes on button press in retracepushbutton.
function retracepushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to retracepushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

background=imopen(current_data,strel('disk',20));
dic2=imsubtract(current_data,background);
im=imadjust(dic2);

delete(handles.current_data);

handles.current_data=imshow(im);










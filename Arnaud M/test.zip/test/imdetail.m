function im=imdetail(dic,rayon)

background=imopen(dic,strel('disk',rayon));
dic2=imsubtract(dic,background);
im=imadjust(dic2);
